/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package transportasi;

/**
 *
 * @author GESIT
 */
public class kendaraan {
    
    private String model;

    //inisialisasi
    public kendaraan(String model){
        this.model = model;
    }
    
    //informasi yang merupakan method tanpa instruksi
    public void informasi(){
        
    }
}
